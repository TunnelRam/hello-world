export { default as CodeAnalysis } from './solidity-analyzer'
