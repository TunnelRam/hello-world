export default {
  SECURITY: { displayName: 'Security', id: 'SEC' },
  GAS: { displayName: 'Gas & Economy', id: 'GAS' },
  MISC: { displayName: 'Miscellaneous', id: 'MISC' },
  ERC: { displayName: 'ERC', id: 'ERC' }
}
