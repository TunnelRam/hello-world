# remix-core-plugin-core-plugin

This library was generated with [Nx](https://nx.dev).
