Community Support
=======================

We know that blockchain ecosystem is very new and that lots of information is scattered around the web.
That is why we created a community support channel where we and other users try to answer your questions if
you get stuck using Remix. Please, join [the community](https://gitter.im/ethereum/remix) and ask for help.

For anyone who is interested in developing a custom plugin for Remix or who wants to contribute to the codebase,
we opened a [contributors' channel](https://gitter.im/ethereum/remix-dev) especially for developers working on Remix tools.

We would kindly ask you to respect the space and to use it for
getting help with your work and the developers' channel for discussions related to working on Remix codebase. If you have
ideas for collaborations or you want to promote your project, try to find some more appropriate channels to do so. Or you can contact
the main contributors directly on Gitter or Twitter.
