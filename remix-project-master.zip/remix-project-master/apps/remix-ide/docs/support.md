Support chat
=======================

We know that blockchain ecosystem is very new and that lots of information is scattered around the web.
That is why we created a community support chat where we and other users try to answer your questions if
you get stuck using Remix. Please, join [the Remix channel](https://gitter.im/ethereum/remix) and ask the community for help.

For anyone who is interested in developing a custom plugin for Remix or who wants to contribute to the codebase,
we've opened [another channel](https://gitter.im/ethereum/remix-dev) specially for developers working on Remix tool.
