module.exports = new (require('../registry.js'))()
